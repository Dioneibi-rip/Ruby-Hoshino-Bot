/**
 * Monitor de Rendimiento y Estabilidad - Ruby-Hoshino-Bot
 * Detecta fugas de memoria, colas atascadas y genera reportes
 */

import os from 'os'

const CHECK_INTERVAL_MS = 60_000      // revisar cada 1 minuto
const MEMORY_WARN_MB = 800            // advertir si memoria > 800 MB
const MEMORY_CRIT_MB = 1400           // crítico si > 1400 MB
const QUEUE_WARN_SIZE = 30            // advertir si hay > 30 mensajes en cola
const DB_SAVE_INTERVAL_MS = 5 * 60_000  // guardar DB cada 5 minutos

let _intervalId = null
let _dbSaveIntervalId = null
let lastMemoryMB = 0
let dbSaveErrors = 0

/**
 * Formatea bytes a MB con 1 decimal.
 */
function toMB(bytes) {
  return (bytes / 1024 / 1024).toFixed(1)
}

/**
 * Obtiene uso de memoria del proceso.
 */
function getMemoryInfo() {
  const mem = process.memoryUsage()
  return {
    rss: parseFloat(toMB(mem.rss)),
    heap: parseFloat(toMB(mem.heapUsed)),
    heapTotal: parseFloat(toMB(mem.heapTotal)),
    external: parseFloat(toMB(mem.external)),
  }
}

/**
 * Obtiene uso de CPU del sistema.
 */
function getCPULoad() {
  const loads = os.loadavg()
  return { load1: loads[0].toFixed(2), load5: loads[1].toFixed(2) }
}

/**
 * Guarda la base de datos de forma segura.
 */
async function safeDBSave() {
  try {
    if (global.db?.data && typeof global.db.write === 'function') {
      await global.db.write(global.db.data)
      dbSaveErrors = 0
    }
  } catch (err) {
    dbSaveErrors++
    console.error(`[Monitor] Error guardando DB (intento ${dbSaveErrors}):`, err?.message || err)
    if (dbSaveErrors >= 3) {
      console.error('[Monitor] ⚠️ Múltiples fallos al guardar DB. Revisar almacenamiento.')
    }
  }
}

/**
 * Realiza una revisión completa del estado del bot.
 */
function checkHealth() {
  const mem = getMemoryInfo()
  const cpu = getCPULoad()

  // Chequeo de memoria
  if (mem.rss > MEMORY_CRIT_MB) {
    console.error(`[Monitor] 🔴 CRÍTICO - Memoria: ${mem.rss} MB RSS / ${mem.heap} MB Heap`)
    // Forzar GC si está disponible
    if (global.gc) {
      global.gc()
      console.log('[Monitor] GC forzado ejecutado')
    }
  } else if (mem.rss > MEMORY_WARN_MB) {
    console.warn(`[Monitor] 🟡 Memoria alta: ${mem.rss} MB RSS / ${mem.heap} MB Heap`)
  }

  // Detectar posible fuga de memoria (subida sostenida > 50 MB/min)
  if (lastMemoryMB > 0 && mem.rss - lastMemoryMB > 50) {
    console.warn(`[Monitor] 📈 Memoria subió ${(mem.rss - lastMemoryMB).toFixed(1)} MB en el último minuto`)
  }
  lastMemoryMB = mem.rss

  // Chequeo de cola de mensajes
  if (global.getQueueStats) {
    const qStats = global.getQueueStats()
    if (qStats.totalQueued > QUEUE_WARN_SIZE) {
      console.warn(`[Monitor] 🟡 Cola grande: ${qStats.totalQueued} mensajes pendientes, ${qStats.activeCount} activos`)
    }
  }

  // Chequeo de plugins cargados
  const pluginCount = Object.keys(global.plugins || {}).length
  if (pluginCount === 0) {
    console.error('[Monitor] 🔴 No hay plugins cargados!')
  }

  return { mem, cpu, pluginCount }
}

/**
 * Genera un reporte de estado legible.
 * Útil para el comando .estadobot
 */
function generateReport() {
  const mem = getMemoryInfo()
  const cpu = getCPULoad()
  const uptime = process.uptime()
  const uptimeFmt = formatUptime(uptime)
  const pluginCount = Object.keys(global.plugins || {}).length
  const qStats = global.getQueueStats?.() || {}

  return {
    uptime: uptimeFmt,
    memory: {
      rss: `${mem.rss} MB`,
      heap: `${mem.heap} MB`,
      heapTotal: `${mem.heapTotal} MB`,
    },
    cpu: {
      load1: cpu.load1,
      load5: cpu.load5,
    },
    plugins: pluginCount,
    queue: qStats,
    dbErrors: dbSaveErrors,
  }
}

function formatUptime(seconds) {
  const d = Math.floor(seconds / 86400)
  const h = Math.floor((seconds % 86400) / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  return [
    d > 0 ? `${d}d` : '',
    h > 0 ? `${h}h` : '',
    m > 0 ? `${m}m` : '',
    `${s}s`,
  ].filter(Boolean).join(' ')
}

/**
 * Inicia el monitor de estabilidad.
 */
function startMonitor() {
  if (_intervalId) return // ya corriendo

  console.log('[Monitor] ✅ Monitor de estabilidad iniciado')

  // Revisión de salud periódica
  _intervalId = setInterval(checkHealth, CHECK_INTERVAL_MS)
  _intervalId.unref?.()

  // Guardado periódico de la DB
  _dbSaveIntervalId = setInterval(safeDBSave, DB_SAVE_INTERVAL_MS)
  _dbSaveIntervalId.unref?.()

  // Manejo de errores no capturados sin cerrar el proceso
  process.on('uncaughtException', (err) => {
    console.error('[Monitor] 🔴 uncaughtException:', err?.message || err)
    // No llamar process.exit() — dejar que el bot siga corriendo
  })

  process.on('unhandledRejection', (reason) => {
    console.error('[Monitor] 🟡 unhandledRejection:', reason?.message || reason)
  })
}

/**
 * Detiene el monitor.
 */
function stopMonitor() {
  if (_intervalId) clearInterval(_intervalId)
  if (_dbSaveIntervalId) clearInterval(_dbSaveIntervalId)
  _intervalId = null
  _dbSaveIntervalId = null
}

export { startMonitor, stopMonitor, generateReport, getMemoryInfo, safeDBSave, checkHealth }
