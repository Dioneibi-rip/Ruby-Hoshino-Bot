/**
 * Plugin: Estado del Bot
 * Muestra información sobre rendimiento, cola de mensajes y memoria
 * Comando: .estadobot / .botstat / .queuestat
 */

import { generateReport } from '../../src/core/stability-monitor.js'

const handler = async (m, { conn, isOwner, isROwner }) => {
  const report = generateReport()
  const q = report.queue

  // Indicadores visuales de estado
  const memMB = parseFloat(report.memory.rss)
  const memStatus = memMB > 1400 ? '🔴' : memMB > 800 ? '🟡' : '🟢'
  const queueStatus = (q.totalQueued || 0) > 30 ? '🔴' : (q.totalQueued || 0) > 10 ? '🟡' : '🟢'

  const text = `╭─────「 🤖 *Estado del Bot* 」─────
│
│ ⏱️ *Uptime:* ${report.uptime}
│ 🔌 *Plugins:* ${report.plugins} cargados
│
├─────「 💾 *Memoria* 」──────
│ ${memStatus} *RSS:* ${report.memory.rss}
│ 📊 *Heap:* ${report.memory.heap} / ${report.memory.heapTotal}
│
├─────「 📬 *Cola de Mensajes* 」──────
│ ${queueStatus} *En cola:* ${q.totalQueued || 0} mensajes
│ ⚡ *Procesando:* ${q.activeCount || 0} activos
│ 👥 *Usuarios en cola:* ${q.usersWithQueue || 0}
│
├─────「 🖥️ *CPU* 」──────
│ 📈 *Carga 1m:* ${report.cpu.load1}
│ 📉 *Carga 5m:* ${report.cpu.load5}
│
├─────「 💾 *Base de Datos* 」──────
│ ${report.dbErrors > 0 ? '🟡' : '🟢'} *Errores DB:* ${report.dbErrors}
│
╰──────────────────────────────`

  await m.reply(text)
}

handler.command = /^(estadobot|botstat|queuestat|botstatus)$/i
handler.owner = false  // cualquiera puede ver, no solo owner

export default handler
