/**
 * Sistema de Cola de Mensajes para Ruby-Hoshino-Bot
 * Evita que mensajes simultáneos se ignoren o pisen entre sí
 */

const MAX_QUEUE_SIZE = 50        // máximo de mensajes en cola por usuario
const MAX_CONCURRENT = 5         // máximo de mensajes procesándose a la vez (global)
const RATE_LIMIT_MS = 1500       // cooldown mínimo entre comandos del mismo usuario (ms)
const RATE_LIMIT_WINDOW = 10000  // ventana de tiempo para rate limiting
const RATE_LIMIT_MAX_CMDS = 8    // máximo de comandos por usuario en la ventana
const QUEUE_TIMEOUT_MS = 30000   // tiempo máximo que un mensaje espera en cola

class MessageQueue {
  constructor() {
    // Cola global de mensajes pendientes: Map<userId, Array<QueueEntry>>
    this.userQueues = new Map()

    // Semáforo global de concurrencia
    this.activeCount = 0

    // Rate limiting: Map<userId, { timestamps: number[], lastCmd: number }>
    this.rateLimits = new Map()

    // Limpieza periódica cada 2 minutos
    this._cleanupInterval = setInterval(() => this._cleanup(), 120_000)
    this._cleanupInterval.unref?.()
  }

  /**
   * Encola un mensaje para ser procesado.
   * @param {string} userId - JID del usuario
   * @param {Function} task - función async () => Promise<void>
   * @param {Object} opts
   * @param {number} opts.priority - 0=normal, 1=alta (owner/admin)
   * @returns {Promise<boolean>} - true si fue aceptado en la cola
   */
  async enqueue(userId, task, opts = {}) {
    // Verificar rate limit antes de encolar
    const rateLimitResult = this._checkRateLimit(userId)
    if (!rateLimitResult.allowed) {
      return { allowed: false, reason: rateLimitResult.reason }
    }

    // Verificar que la cola del usuario no esté llena
    const userQueue = this.userQueues.get(userId) || []
    if (userQueue.length >= MAX_QUEUE_SIZE) {
      return { allowed: false, reason: 'queue_full' }
    }

    // Crear entrada de cola
    const entry = {
      userId,
      task,
      priority: opts.priority || 0,
      enqueuedAt: Date.now(),
      timeoutId: null,
    }

    // Timeout para que mensajes viejos no bloqueen la cola
    entry.timeoutId = setTimeout(() => {
      this._removeFromQueue(userId, entry)
    }, QUEUE_TIMEOUT_MS)

    // Agregar a la cola del usuario
    userQueue.push(entry)

    // Ordenar por prioridad (mayor primero)
    if (entry.priority > 0) {
      userQueue.sort((a, b) => b.priority - a.priority)
    }

    this.userQueues.set(userId, userQueue)
    this._recordCommand(userId)

    // Intentar procesar inmediatamente
    this._tryProcess()

    return { allowed: true }
  }

  /**
   * Intenta procesar el siguiente mensaje en cola si hay capacidad.
   */
  _tryProcess() {
    if (this.activeCount >= MAX_CONCURRENT) return

    // Buscar el próximo mensaje para procesar (round-robin entre usuarios)
    const nextEntry = this._getNextEntry()
    if (!nextEntry) return

    const { userId, entry } = nextEntry

    // Remover de la cola
    this._removeFromQueue(userId, entry)

    // Cancelar timeout
    if (entry.timeoutId) {
      clearTimeout(entry.timeoutId)
      entry.timeoutId = null
    }

    this.activeCount++

    // Ejecutar la tarea
    Promise.resolve()
      .then(() => entry.task())
      .catch(err => console.error('[MessageQueue] Error en tarea:', err))
      .finally(() => {
        this.activeCount--
        // Intentar procesar el siguiente tras un tick
        setImmediate(() => this._tryProcess())
      })
  }

  /**
   * Obtiene el siguiente entry a procesar usando round-robin.
   */
  _getNextEntry() {
    for (const [userId, queue] of this.userQueues.entries()) {
      if (queue.length === 0) {
        this.userQueues.delete(userId)
        continue
      }
      // Verificar cooldown entre comandos del mismo usuario
      const rl = this.rateLimits.get(userId)
      if (rl && Date.now() - rl.lastProcessed < RATE_LIMIT_MS) {
        continue // respetar cooldown, buscar otro usuario
      }
      return { userId, entry: queue[0] }
    }
    return null
  }

  /**
   * Registra un comando para rate limiting.
   */
  _recordCommand(userId) {
    const now = Date.now()
    let rl = this.rateLimits.get(userId)
    if (!rl) {
      rl = { timestamps: [], lastProcessed: 0 }
      this.rateLimits.set(userId, rl)
    }
    rl.timestamps.push(now)
    // Limpiar timestamps viejos
    rl.timestamps = rl.timestamps.filter(t => now - t < RATE_LIMIT_WINDOW)
  }

  /**
   * Marca que un usuario acaba de ser procesado.
   */
  markProcessed(userId) {
    const rl = this.rateLimits.get(userId)
    if (rl) rl.lastProcessed = Date.now()
  }

  /**
   * Verifica si el usuario puede enviar un comando.
   */
  _checkRateLimit(userId) {
    const now = Date.now()
    const rl = this.rateLimits.get(userId)
    if (!rl) return { allowed: true }

    // Limpiar timestamps viejos
    rl.timestamps = rl.timestamps.filter(t => now - t < RATE_LIMIT_WINDOW)

    if (rl.timestamps.length >= RATE_LIMIT_MAX_CMDS) {
      return { allowed: false, reason: 'rate_limit' }
    }

    return { allowed: true }
  }

  /**
   * Remueve una entrada específica de la cola de un usuario.
   */
  _removeFromQueue(userId, entry) {
    const queue = this.userQueues.get(userId)
    if (!queue) return
    const idx = queue.indexOf(entry)
    if (idx !== -1) queue.splice(idx, 1)
    if (queue.length === 0) this.userQueues.delete(userId)
  }

  /**
   * Limpieza periódica de datos obsoletos.
   */
  _cleanup() {
    const now = Date.now()

    // Limpiar colas vacías
    for (const [userId, queue] of this.userQueues.entries()) {
      // Remover entradas con timeout expirado
      const expired = queue.filter(e => now - e.enqueuedAt > QUEUE_TIMEOUT_MS)
      for (const e of expired) {
        if (e.timeoutId) clearTimeout(e.timeoutId)
        this._removeFromQueue(userId, e)
      }
      if (queue.length === 0) this.userQueues.delete(userId)
    }

    // Limpiar rate limits inactivos
    for (const [userId, rl] of this.rateLimits.entries()) {
      rl.timestamps = rl.timestamps.filter(t => now - t < RATE_LIMIT_WINDOW)
      if (rl.timestamps.length === 0 && now - rl.lastProcessed > RATE_LIMIT_WINDOW) {
        this.rateLimits.delete(userId)
      }
    }
  }

  /**
   * Estadísticas de la cola (para debug/monitoreo).
   */
  getStats() {
    let totalQueued = 0
    for (const q of this.userQueues.values()) totalQueued += q.length
    return {
      activeCount: this.activeCount,
      totalQueued,
      usersWithQueue: this.userQueues.size,
      rateLimitedUsers: this.rateLimits.size,
    }
  }

  destroy() {
    clearInterval(this._cleanupInterval)
    for (const [, queue] of this.userQueues.entries()) {
      for (const e of queue) {
        if (e.timeoutId) clearTimeout(e.timeoutId)
      }
    }
    this.userQueues.clear()
    this.rateLimits.clear()
  }
}

// Singleton global
const globalMessageQueue = new MessageQueue()

export default globalMessageQueue
export { MessageQueue, RATE_LIMIT_MS, RATE_LIMIT_MAX_CMDS }
