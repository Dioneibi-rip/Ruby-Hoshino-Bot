import { smsg } from './lib/simple.js'
import { format } from 'util'
import * as ws from 'ws'
import { join } from 'path'
import { fileURLToPath } from 'url'
import { unwatchFile, watchFile } from 'fs'
import chalk from 'chalk'
import failureHandler from './lib/respuesta.js'
import {
  buildPermissionContext,
  createParticipantIndex,
  getCachedGroupMetadata,
  commandMatches,
  getPluginDirectory,
  getPrefixMatch,
  hydrateDatabaseForMessage,
  isNumber,
  normalizeLidReferences,
  runMaintenance,
} from './src/core/handler-utils.js'
import { attachSessionState } from './src/core/session-manager.js'
import messageQueue from './src/core/message-queue.js'

global.uptimeStart = Date.now()

const SYSTEM_MESSAGE_MAX_AGE_MS = 60_000
const IGNORED_BAILEYS_IDS = [/^NJX-/, /^BAE5.{12}$/, /^B24E.{16}$/]
const UNBAN_COMMAND_FILES = ['grupo-unbanchat.js', 'enable/grupo-unbanchat.js']

// ──────────────────────────────────────────────────────────────
// DEDUPLICACIÓN: evita procesar el mismo mensaje dos veces
// (puede pasar con reconexiones de Baileys)
// ──────────────────────────────────────────────────────────────
const processedIds = new Set()
const PROCESSED_TTL_MS = 5 * 60 * 1000 // 5 minutos
const processedTimestamps = new Map()

function markProcessed(id) {
  processedIds.add(id)
  processedTimestamps.set(id, Date.now())
}

function isAlreadyProcessed(id) {
  return processedIds.has(id)
}

// Limpia IDs viejos cada 3 minutos
const dedupeCleanup = setInterval(() => {
  const now = Date.now()
  for (const [id, ts] of processedTimestamps.entries()) {
    if (now - ts > PROCESSED_TTL_MS) {
      processedIds.delete(id)
      processedTimestamps.delete(id)
    }
  }
}, 3 * 60 * 1000)
dedupeCleanup.unref?.()

// ──────────────────────────────────────────────────────────────
// HELPERS
// ──────────────────────────────────────────────────────────────

function getLatestMessage(chatUpdate) {
  const messages = Array.isArray(chatUpdate?.messages) ? chatUpdate.messages : []
  return messages.at(-1) || null
}

function isFreshMessage(message) {
  const rawTimestamp = Number(message?.messageTimestamp || 0)
  const messageTime = rawTimestamp > 0 ? rawTimestamp * 1000 : Date.now()
  return Date.now() - messageTime <= SYSTEM_MESSAGE_MAX_AGE_MS
}

function shouldIgnoreBaileysMessage(m) {
  if (!m?.fromMe && !m?.isBaileys) return false
  const id = m?.id || m?.key?.id || ''
  return IGNORED_BAILEYS_IDS.some((pattern) => pattern.test(id))
}

function parseCommand(text, usedPrefix) {
  const noPrefix = text.replace(usedPrefix, '')
  const parts = noPrefix.trim().split` `.filter(Boolean)
  const [rawCommand, ...args] = parts
  const _args = noPrefix.trim().split` `.slice(1)
  return {
    noPrefix,
    args,
    _args,
    text: _args.join` `,
    command: (rawCommand || '').toLowerCase(),
  }
}

async function runPluginHooks(conn, plugin, name, m, context) {
  if (typeof plugin?.all === 'function') {
    try {
      await plugin.all.call(conn, m, context)
    } catch (error) {
      console.error(error)
    }
  }
}

function sanitizeError(error) {
  let text = format(error)
  for (const key of Object.values(global.APIKeys || {}))
    text = text.replace(new RegExp(key, 'g'), 'Administrador')
  return text
}

async function executePlugin(conn, plugin, name, m, extra, permissionContext, sender) {
  const { isROwner, isOwner, isMods, isPrems, isAdmin, isBotAdmin } = permissionContext
  const fail = plugin.fail || global.dfail
  const chat = global.db?.data?.chats?.[m.chat]
  const user = global.db?.data?.users?.[sender]

  if (m.isGroup && !UNBAN_COMMAND_FILES.includes(name) && chat?.isBanned === true && !isROwner)
    return true
  if (m.text && user?.banned && !isROwner) {
    if (!user.lastBanMsg || Date.now() - user.lastBanMsg > 30_000) {
      m.reply(
        `《✦》Estas baneado/a, no puedes usar comandos en este bot!\n\n${user.bannedReason ? `✰ *Motivo:* ${user.bannedReason}` : '✰ *Motivo:* Sin Especificar'}\n\n> ✧ Si este Bot es cuenta ...`,
      )
      user.lastBanMsg = Date.now()
    }
    return true
  }
  if (user?.antispam && !user.banned) user.antispam = 0

  const adminMode = chat?.modoadmin
  if (adminMode && m.isGroup && !isAdmin && !isOwner && !isROwner) return true
  if (plugin.botAdmin && !isBotAdmin) {
    fail('botAdmin', m, conn)
    return false
  }
  if (plugin.rowner && plugin.owner && !(isROwner || isOwner)) {
    fail('owner', m, conn)
    return false
  }
  if (plugin.rowner && !isROwner) {
    fail('rowner', m, conn)
    return false
  }
  if (plugin.owner && !isOwner) {
    fail('owner', m, conn)
    return false
  }
  if (plugin.mods && !isMods) {
    fail('mods', m, conn)
    return false
  }
  if (plugin.premium && !isPrems) {
    fail('premium', m, conn)
    return false
  }
  if (plugin.admin && !isAdmin) {
    fail('admin', m, conn)
    return false
  }
  if (plugin.private && m.isGroup) {
    fail('private', m, conn)
    return false
  }
  if (plugin.group && !m.isGroup) {
    fail('group', m, conn)
    return false
  }

  m.isCommand = true
  const xp = 'exp' in plugin ? parseInt(plugin.exp) : 17
  if (xp > 200) m.reply('chirrido -_-')
  else m.exp += xp

  if (
    !isPrems &&
    plugin.coin &&
    (global.db?.data?.users?.[sender]?.coin || 0) < plugin.coin * 1
  ) {
    conn.reply(m.chat, `❮✦❯ Se agotaron tus ${m.moneda}`, m)
    return false
  }
  if (plugin.level > (user?.level || 0)) {
    conn.reply(
      m.chat,
      `❮✦❯ Se requiere el nivel: *${plugin.level}*\n\n• Tu nivel actual es: *${user?.level || 0}*\n\n• Usa este comando para subir de nivel:\n*${extra.usedPrefix}levelup*`,
      m,
    )
    return false
  }

  try {
    await plugin.call(conn, m, extra)
    if (!isPrems) m.coin = m.coin || plugin.coin || false
  } catch (error) {
    m.error = error
    console.error(error)
    if (error) m.reply(sanitizeError(error))
  } finally {
    if (typeof plugin.after === 'function') {
      try {
        await plugin.after.call(conn, m, extra)
      } catch (error) {
        console.error(error)
      }
    }
    if (m.coin) conn.reply(m.chat, `❮✦❯ Utilizaste ${+m.coin} ${m.moneda}`, m)
  }
  return true
}

function isUserMutedInChat(user, chatId) {
  if (!user || !chatId) return false
  if (user.mutedChats?.[chatId] === true) return true
  return user.muto === true && (!user.mutoChat || user.mutoChat === chatId)
}

function getMessageDeletePayload(m, sender) {
  const key = m?.__deleteKey || m?.key || {}
  const id = key.id || m?.id
  const remoteJid = key.remoteJid || m?.chat
  if (!id || !remoteJid) return null
  const payload = { remoteJid, fromMe: Boolean(key.fromMe), id }
  const participant = key.participant || m?.participant || sender
  if (m?.isGroup && participant) payload.participant = participant
  return payload
}

function updateStatsAndEconomy(conn, m, sender) {
  const data = global.db?.data
  if (!data || !m) return
  const mutedUser = data.users?.[sender]
  if (m.isGroup && isUserMutedInChat(mutedUser, m.chat)) {
    const deletePayload = getMessageDeletePayload(m, sender)
    if (deletePayload)
      conn.sendMessage?.(m.chat, { delete: deletePayload }).catch(() => {})
  }
  if (sender && data.users?.[sender]) {
    data.users[sender].exp += m.exp || 0
    data.users[sender].coin -= (m.coin || 0) * 1
  }
  if (!m.plugin) return
  const stats = (data.stats ||= {})
  const now = Date.now()
  const stat = (stats[m.plugin] ||= {
    total: 0,
    success: 0,
    last: now,
    lastSuccess: 0,
  })
  if (!isNumber(stat.total)) stat.total = 0
  if (!isNumber(stat.success)) stat.success = 0
  if (!isNumber(stat.last)) stat.last = now
  if (!isNumber(stat.lastSuccess)) stat.lastSuccess = 0
  stat.total += 1
  stat.last = now
  if (m.error == null) {
    stat.success += 1
    stat.lastSuccess = now
  }
}

// ──────────────────────────────────────────────────────────────
// LÓGICA PRINCIPAL DEL MENSAJE (desacoplada de la cola)
// ──────────────────────────────────────────────────────────────

async function processMessage(conn, chatUpdate, rawMessage) {
  let m = null
  let sender = null
  try {
    m = smsg(conn, rawMessage) || rawMessage
    if (!m) return
    const opts = conn.opts || global.opts || {}
    if (typeof m.text !== 'string') m.text = ''

    if (m.isGroup) {
      const chat = global.db?.data?.chats?.[m.chat]
      const primaryBot = chat?.primaryBot || chat?.botPrimario
      if (primaryBot) {
        const universalWords = ['resetbot', 'resetprimario', 'botreset']
        const firstWord =
          m.text
            .trim()
            .split(' ')[0]
            ?.toLowerCase()
            .replace(/^[./#]/, '') || ''
        if (!universalWords.includes(firstWord) && conn?.user?.jid !== primaryBot) return
      }
    }

    sender = m.isGroup
      ? m.key?.participant || m.sender
      : m.key?.remoteJid || m.sender
    if (!sender) return
    m.__deleteKey = m.key ? { ...m.key } : null
    const groupMetadata = m.isGroup ? await getCachedGroupMetadata(conn, m.chat) : {}
    const participants = Array.isArray(groupMetadata?.participants)
      ? groupMetadata.participants
      : []
    sender = normalizeLidReferences(
      m,
      sender,
      m.isGroup ? createParticipantIndex(participants) : null,
    )

    m.exp = 0
    m.coin = false
    const { user: _user, settings } = hydrateDatabaseForMessage(conn, m, sender)

    if (opts.nyimak) return
    if (!m.fromMe && opts.self) return
    if (opts.swonly && m.chat !== 'status@broadcast') return

    const permissionContext = buildPermissionContext(conn, m, sender, participants)
    const {
      userGroup,
      botGroup,
      isRAdmin,
      isAdmin,
      isBotAdmin,
      isROwner,
      isOwner,
      isMods,
      isPrems,
    } = permissionContext
    m.moneda = settings?.moneda || 'Coins'
    m.exp += Math.ceil(Math.random() * 10)

    // Determinar prioridad para la cola (owners/admins tienen prioridad alta)
    const priority = isROwner || isOwner ? 1 : 0

    const pluginDir = getPluginDirectory()
    for (const name in global.plugins || {}) {
      const plugin = global.plugins[name]
      if (!plugin || plugin.disabled) continue
      const __filename = join(pluginDir, name)
      const baseContext = { chatUpdate, __dirname: pluginDir, __filename }
      await runPluginHooks(conn, plugin, name, m, baseContext)
      if (!opts.restrict && plugin.tags?.includes?.('admin')) continue

      const match = getPrefixMatch(conn, plugin, m.text)
      const beforeContext = {
        match,
        conn,
        participants,
        groupMetadata,
        user: userGroup,
        bot: botGroup,
        isROwner,
        isOwner,
        isRAdmin,
        isAdmin,
        isBotAdmin,
        isPrems,
        chatUpdate,
        __dirname: pluginDir,
        __filename,
      }
      if (typeof plugin.before === 'function') {
        const beforeResult = await plugin.before.call(conn, m, beforeContext)
        if (m.__pluginHalt) return
        if (beforeResult) continue
      }
      if (m.__pluginHalt) return
      if (typeof plugin !== 'function' || !match?.[0]?.[0]) continue

      const usedPrefix = match[0][0]
      const parsed = parseCommand(m.text, usedPrefix)
      const isAccept = commandMatches(plugin.command, parsed.command)
      global.comando = parsed.command
      if (shouldIgnoreBaileysMessage(m)) return
      if (!isAccept) continue
      m.plugin = name
      const chatData = global.db?.data?.chats?.[m.chat] || {}
      const isBotBannedInThisChat =
        Array.isArray(chatData.bannedBots) &&
        chatData.bannedBots.includes(conn.user?.jid)
      if (isBotBannedInThisChat && !UNBAN_COMMAND_FILES.includes(name)) return

      const extra = {
        match,
        usedPrefix,
        ...parsed,
        conn,
        participants,
        groupMetadata,
        user: userGroup,
        bot: botGroup,
        isROwner,
        isOwner,
        isRAdmin,
        isAdmin,
        isBotAdmin,
        isPrems,
        chatUpdate,
        __dirname: pluginDir,
        __filename,
      }

      // Marcar como procesado antes de ejecutar para evitar duplicados
      const msgId = m.id || m.key?.id
      if (msgId) markProcessed(msgId)

      await executePlugin(conn, plugin, name, m, extra, permissionContext, sender)

      // Registrar que este usuario fue procesado (cooldown)
      messageQueue.markProcessed(sender)
      break
    }
  } catch (error) {
    console.error('[handler] Error procesando mensaje:', error)
  } finally {
    try {
      updateStatsAndEconomy(conn, m, sender)
    } catch (error) {
      console.error(error)
    }
    try {
      const printMod = await import('./lib/print.js')
      const opts = conn.opts || global.opts || {}
      if (!opts.noprint && m) await printMod.default(m, conn)
    } catch (error) {
      console.log(chalk.red('Error en print.js'), error)
    }
  }
}

// ──────────────────────────────────────────────────────────────
// HANDLER PRINCIPAL - ahora usa la cola de mensajes
// ──────────────────────────────────────────────────────────────

export async function handler(chatUpdate) {
  attachSessionState(this)
  runMaintenance(this)

  const rawMessage = getLatestMessage(chatUpdate)
  if (!rawMessage || !isFreshMessage(rawMessage)) return

  // Deduplicación: ignorar mensajes que ya procesamos
  const msgId = rawMessage?.key?.id
  if (msgId && isAlreadyProcessed(msgId)) return

  this.pushMessage?.(chatUpdate?.messages || []).catch(console.error)
  if (global.db && global.db.data == null) await global.loadDatabase?.()

  // Determinar el sender para la cola
  const isGroup = rawMessage?.key?.remoteJid?.endsWith('@g.us') || false
  const sender = isGroup
    ? rawMessage?.key?.participant || rawMessage?.participant || rawMessage?.key?.remoteJid
    : rawMessage?.key?.remoteJid || 'unknown'

  // Captura `this` (conn) para el closure
  const conn = this

  // Encolar el procesamiento del mensaje
  const result = await messageQueue.enqueue(
    sender,
    () => processMessage(conn, chatUpdate, rawMessage),
    {
      priority: 0, // se ajusta dentro si es owner
    }
  )

  // Feedback de rate limiting (opcional, puede comentarse si es muy verboso)
  if (result && !result.allowed) {
    if (result.reason === 'rate_limit') {
      // No respondemos para no generar más carga, solo logueamos
      console.log(chalk.yellow(`[Queue] Rate limit para ${sender}: demasiados comandos`))
    } else if (result.reason === 'queue_full') {
      console.log(chalk.red(`[Queue] Cola llena para ${sender}`))
    }
  }
}

global.dfail = (type, m, conn) => {
  failureHandler(type, conn, m)
}

// Exponer stats de la cola globalmente (útil para comando .estadobot)
global.getQueueStats = () => messageQueue.getStats()

const file =
  typeof global.__filename === 'function'
    ? global.__filename(import.meta.url, true)
    : fileURLToPath(import.meta.url)

watchFile(file, async () => {
  unwatchFile(file)
  console.log(chalk.green('Actualizando "handler.js"'))
  if (global.conns?.length > 0) {
    const users = [
      ...new Set(
        global.conns.filter(
          (conn) =>
            conn.user &&
            conn.ws?.socket &&
            conn.ws.socket.readyState !== ws.CLOSED,
        ),
      ),
    ]
    for (const userr of users) {
      try {
        userr.subreloadHandler(false)
      } catch {}
    }
  }
})
