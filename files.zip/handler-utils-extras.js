/**
 * Mejoras para handler-utils.js
 * Caché de metadata de grupos más robusta y evita llamadas redundantes
 *
 * CÓMO USAR:
 * Reemplaza o complementa getCachedGroupMetadata en tu handler-utils.js
 * con las versiones mejoradas de este archivo.
 */

// ──────────────────────────────────────────────────────────────
// CACHÉ MEJORADA DE GROUP METADATA
// ──────────────────────────────────────────────────────────────

const GROUP_META_CACHE = new Map()
const GROUP_META_TTL = 5 * 60 * 1000      // 5 minutos
const GROUP_META_FETCHING = new Map()      // evita fetches simultáneos del mismo grupo

/**
 * Obtiene metadata del grupo con caché y deduplicación de requests.
 * Si dos mensajes del mismo grupo llegan al mismo tiempo, solo hace
 * UNA llamada a groupMetadata() en lugar de dos.
 *
 * @param {object} conn - Conexión de Baileys
 * @param {string} jid  - JID del grupo
 * @returns {Promise<object>}
 */
export async function getCachedGroupMetadataV2(conn, jid) {
  if (!jid || !jid.endsWith('@g.us')) return {}

  const now = Date.now()
  const cached = GROUP_META_CACHE.get(jid)

  // Devolver caché válida
  if (cached && now - cached.fetchedAt < GROUP_META_TTL) {
    return cached.data
  }

  // Si ya hay un fetch en curso para este grupo, esperar ese resultado
  if (GROUP_META_FETCHING.has(jid)) {
    try {
      return await GROUP_META_FETCHING.get(jid)
    } catch {
      return cached?.data || {}
    }
  }

  // Iniciar fetch y guardarlo para deduplicación
  const fetchPromise = conn.groupMetadata(jid)
    .then(meta => {
      GROUP_META_CACHE.set(jid, { data: meta, fetchedAt: Date.now() })
      GROUP_META_FETCHING.delete(jid)
      return meta
    })
    .catch(err => {
      GROUP_META_FETCHING.delete(jid)
      console.error(`[GroupMeta] Error obteniendo metadata de ${jid}:`, err?.message)
      return cached?.data || {}
    })

  GROUP_META_FETCHING.set(jid, fetchPromise)
  return fetchPromise
}

/**
 * Invalida la caché de un grupo (útil cuando cambian participantes/nombre).
 * @param {string} jid
 */
export function invalidateGroupCache(jid) {
  GROUP_META_CACHE.delete(jid)
}

/**
 * Invalida toda la caché de grupos.
 */
export function clearAllGroupCache() {
  GROUP_META_CACHE.clear()
}

// Limpieza periódica del caché de grupos
const groupCacheCleanup = setInterval(() => {
  const now = Date.now()
  for (const [jid, entry] of GROUP_META_CACHE.entries()) {
    if (now - entry.fetchedAt > GROUP_META_TTL * 2) {
      GROUP_META_CACHE.delete(jid)
    }
  }
}, 10 * 60 * 1000)
groupCacheCleanup.unref?.()

// ──────────────────────────────────────────────────────────────
// RETRY WRAPPER
// Reintenta una operación N veces con backoff exponencial
// ──────────────────────────────────────────────────────────────

/**
 * Ejecuta una función async con reintentos automáticos.
 * Útil para operaciones de red que pueden fallar temporalmente.
 *
 * @param {Function} fn - Función async a ejecutar
 * @param {object} opts
 * @param {number} opts.retries - Número máximo de reintentos (default: 3)
 * @param {number} opts.baseDelay - Delay base en ms (default: 500)
 * @param {string} opts.label - Etiqueta para logs
 * @returns {Promise<any>}
 */
export async function withRetry(fn, { retries = 3, baseDelay = 500, label = 'op' } = {}) {
  let lastErr
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err
      if (attempt < retries) {
        const delay = baseDelay * Math.pow(2, attempt)
        console.warn(`[Retry] ${label} falló (intento ${attempt + 1}/${retries + 1}), reintentando en ${delay}ms`)
        await new Promise(r => setTimeout(r, delay))
      }
    }
  }
  throw lastErr
}

// ──────────────────────────────────────────────────────────────
// THROTTLE DE ENVÍO DE MENSAJES
// Evita que el bot envíe mensajes demasiado rápido (anti-ban)
// ──────────────────────────────────────────────────────────────

const MESSAGE_THROTTLE_MS = 300  // mínimo entre mensajes al mismo chat
const lastMessageTimes = new Map()

/**
 * Envuelve conn.sendMessage con throttling automático.
 * Previene que WhatsApp detecte el bot como spam.
 *
 * @param {object} conn
 * @param {string} jid
 * @param {object} content
 * @param {object} options
 */
export async function throttledSend(conn, jid, content, options = {}) {
  const now = Date.now()
  const lastTime = lastMessageTimes.get(jid) || 0
  const elapsed = now - lastTime

  if (elapsed < MESSAGE_THROTTLE_MS) {
    await new Promise(r => setTimeout(r, MESSAGE_THROTTLE_MS - elapsed))
  }

  lastMessageTimes.set(jid, Date.now())

  // Limpiar entradas viejas ocasionalmente
  if (lastMessageTimes.size > 500) {
    const cutoff = Date.now() - 60_000
    for (const [key, time] of lastMessageTimes.entries()) {
      if (time < cutoff) lastMessageTimes.delete(key)
    }
  }

  return conn.sendMessage(jid, content, options)
}

// ──────────────────────────────────────────────────────────────
// SAFE REPLY
// reply() que no rompe si el chat ya no existe
// ──────────────────────────────────────────────────────────────

/**
 * Versión segura de reply que captura errores silenciosamente.
 * Útil para respuestas en grupos que pueden haber borrado el mensaje.
 */
export async function safeReply(conn, jid, text, quoted, options = {}) {
  try {
    return await conn.sendMessage(jid, { text, ...options }, { quoted, ...options })
  } catch (err) {
    // Ignorar errores de "message not found" o "chat not found"
    if (/not found|no longer|does not exist/i.test(err?.message || '')) return null
    console.error('[safeReply] Error:', err?.message)
    return null
  }
}
