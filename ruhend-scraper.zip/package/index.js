const { ttdl, igdl, fbdl, igdl2, fbdl2, ytsearch } = require('./main.js');
module.exports = { ttdl, igdl, fbdl, igdl2, fbdl2, ytsearch };