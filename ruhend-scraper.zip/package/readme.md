## Downloader Media 

Usage

🎗 TIKTOK

```ts
const { ttdl } = require('ruhend-scraper')
import { ttdl } from 'ruhend-scraper'

const url = 'https://vt.tiktok.com/xxxx'
let { title, author, username, published, like, comment, share, views, bookmark, video, cover, music, profilePicture } = await ttdl(url);
or
let data = await ttdl(url)
console.log(data)
/*
results JSON
{ title, author, username, published, like, comment, share, views, bookmark, video, cover, music, profilePicture }
*/
```
/**
Removed
🎗 YTMP3 

```ts
const { ytmp3 } = require('ruhend-scraper')
import { ytmp3 } from 'ruhend-scraper'

const url = 'youtube link'
const { title, audio, author, description, duration, views, upload, thumbnail } = await ytmp3(url);
or 
const data = await ytmp3(url)
return data or console.log(data)

```

🎗 YTMP4
Removed
```ts
const { ytmp4 } = require('ruhend-scraper')
import { ytmp4 } from 'ruhend-scraper'

const url = 'youtube link'
const { title, audio, author, description, duration, views, upload, thumbnail } = await ytmp4(url);
or 
const data = await ytmp4(url)
return data or console.log(data)
```
**/

🎗 INSTAGRAM

```ts
const { igdl } = require('ruhend-scraper')
import { igdl } from 'ruhend-scraper'
const text = "link instagram" //https://instagram.com/xxxxxxx
const res = await igdl(text);
console.log(res);   

```


🎗 FACEBOOK

```ts
const { fbdl } = require('ruhend-scraper')
import { fbdl } from 'ruhend-scraper'
const text = "link Facebook" //https://Facebook.com/xxxxxxx
const res = await fbdl(text);
console.log(res); 
   
```


🎗 YOUTUBE SEARCH

```ts
   const { ytsearch } = require('ruhend-scraper')
   import { ytsearch } from 'ruhend-scraper'
   const text = "link youtube , title or something that u wanna search " //https://instagram.com/xxxxxxx

   let { video, channel } = await ytsearch(text)
      let teks = [...video, ...
         channel
      ].map(v => {
         switch (v.type) {
            case 'video':
               return `
      ${javi} *${v.title}* 
      ${java} *${v.url}*
      ${java} Duration: ${v.durationH}
      ${java} Uploaded ${v.publishedTime}
      ${java} ${v.view} views`.trim()
            case 'channel':
               return `
      ╭──────━• *CHANNEL*
      │🎀 *${v.channelName}* 
      │🔗 *${v.url}*
      │📛 _${v.subscriberH} Subscriber_
      │🎥 ${v.videoCount} video
      ┗──────━•`.trim()
         }
      }).filter(v => v).join(
         '\n\n─────────────━─────────────\n\n'
      )
      console.log(teks)

```
